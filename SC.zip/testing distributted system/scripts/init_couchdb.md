# CouchDB bootstrap

1. Open Fauxton on `http://localhost:5984/_utils`
2. Create database `edge_stress`
3. Use the same admin credentials on all three nodes
4. Configure replication:
   - couch1 → couch2
   - couch2 → couch3
   - couch3 → couch1

This keeps the setup aligned with the paper’s three-node CouchDB cluster.
