import argparse
import os
import pandas as pd
import matplotlib.pyplot as plt

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--outdir", default="analysis/plots")
    args = parser.parse_args()

    os.makedirs(args.outdir, exist_ok=True)
    df = pd.read_csv(args.input)

    pivot = df.groupby(["workload", "db"])["throughput_ops_sec"].mean().unstack()
    ax = pivot.plot(kind="bar")
    ax.set_xlabel("Workload")
    ax.set_ylabel("Throughput (ops/sec)")
    ax.set_title("Baseline Throughput Comparison")
    plt.tight_layout()
    plt.savefig(os.path.join(args.outdir, "throughput.png"))
    plt.close()

    pivot2 = df.groupby(["workload", "db"])["avg_latency_ms"].mean().unstack()
    ax = pivot2.plot(kind="bar")
    ax.set_xlabel("Workload")
    ax.set_ylabel("Average latency (ms)")
    ax.set_title("Average Latency Comparison")
    plt.tight_layout()
    plt.savefig(os.path.join(args.outdir, "latency.png"))
    plt.close()

if __name__ == "__main__":
    main()
