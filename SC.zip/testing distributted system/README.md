# Edge DB Stress Test Environment

This project is aligned with the paper methodology:
- 9 Docker nodes total: 3 MongoDB, 3 CouchDB, 3 Cassandra
- 3 simulated zones
- 5 workloads: E1–E5
- 5 fault scenarios: F1–F5
- Repeated runs + CSV output for graphs

## Paper mapping

- **Environment setup / 9 nodes / 3 zones** → `docker-compose.yml`
- **MongoDB replica set** → `scripts/init_mongo.js`
- **Cassandra keyspace/table** → `scripts/init_cassandra.cql`
- **CouchDB cluster bootstrap notes** → `scripts/init_couchdb.md`
- **Workloads E1–E5** → `src/workloads.py`
- **Faults F1–F5** → `src/faults.sh`
- **Full experiment matrix** → `src/run_experiments.py`
- **Graphs** → `analysis/plot_results.py`

The paper describes Docker-based edge emulation with 2 GB RAM and 2 vCPUs per node, 20–80 ms inter-zone latency, five YCSB-style workloads, five injected faults, and 900 total experiments. This environment follows the same structure and naming. fileciteturn0file1 fileciteturn0file0

## Quick start

1. Start containers:
   ```bash
   docker compose up -d
   ```

2. Initialize MongoDB replica set:
   ```bash
   docker exec -it mongo1 mongosh /scripts/init_mongo.js
   ```

3. Initialize Cassandra schema:
   ```bash
   docker exec -it cassandra1 cqlsh -f /scripts/init_cassandra.cql
   ```

4. Install Python deps:
   ```bash
   pip install -r requirements.txt
   ```

5. Run baseline experiments:
   ```bash
   python src/run_experiments.py --db mongo --workload E1 --repeats 10 --duration 30
   ```

6. Generate graphs:
   ```bash
   python analysis/plot_results.py --input results/results.csv
   ```
