import random
import time
from common import generate_record

def e1_read_heavy(store, duration_s=30):
    end = time.time() + duration_s
    ops = 0
    while time.time() < end:
        if random.random() < 0.85:
            store.read(random.randint(1, 100_000))
        else:
            store.write(generate_record())
        ops += 1
    return ops

def e2_write_heavy(store, duration_s=30):
    end = time.time() + duration_s
    ops = 0
    while time.time() < end:
        if random.random() < 0.85:
            store.write(generate_record())
        else:
            store.read(random.randint(1, 100_000))
        ops += 1
    return ops

def e3_mixed(store, duration_s=30):
    end = time.time() + duration_s
    ops = 0
    while time.time() < end:
        if random.random() < 0.5:
            store.read(random.randint(1, 100_000))
        else:
            store.write(generate_record())
        ops += 1
    return ops

def e4_scan_heavy(store, duration_s=30):
    end = time.time() + duration_s
    ops = 0
    while time.time() < end:
        store.scan(limit=100)
        ops += 1
    return ops

def e5_burst(store, duration_s=30):
    end = time.time() + duration_s
    ops = 0
    while time.time() < end:
        burst = random.randint(20, 80)
        for _ in range(burst):
            store.write(generate_record())
            ops += 1
        time.sleep(random.uniform(0.2, 1.0))
    return ops

WORKLOADS = {
    "E1": e1_read_heavy,
    "E2": e2_write_heavy,
    "E3": e3_mixed,
    "E4": e4_scan_heavy,
    "E5": e5_burst,
}
