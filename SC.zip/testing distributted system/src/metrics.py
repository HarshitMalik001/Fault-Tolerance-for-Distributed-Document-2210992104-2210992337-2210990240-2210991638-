import csv
import os

class MetricWriter:
    def __init__(self, path="results/results.csv"):
        self.path = path
        os.makedirs(os.path.dirname(path), exist_ok=True)
        new_file = not os.path.exists(path) or os.path.getsize(path) == 0
        self.fp = open(path, "a", newline="", encoding="utf-8")
        self.writer = csv.DictWriter(
            self.fp,
            fieldnames=["db", "workload", "fault", "rep", "ops", "duration_s", "throughput_ops_sec", "avg_latency_ms", "note"],
        )
        if new_file:
            self.writer.writeheader()

    def write_row(self, **row):
        self.writer.writerow(row)
        self.fp.flush()

    def close(self):
        self.fp.close()
