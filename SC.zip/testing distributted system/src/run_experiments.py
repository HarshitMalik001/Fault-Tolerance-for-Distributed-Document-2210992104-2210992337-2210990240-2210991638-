import argparse
import time
from statistics import mean

from clients import get_store
from workloads import WORKLOADS
from common import generate_record
from metrics import MetricWriter

def benchmark(db_name, workload_key, duration_s=30):
    store = get_store(db_name)
    latencies = []
    ops = 0
    end = time.time() + duration_s

    while time.time() < end:
        t0 = time.perf_counter()
        if workload_key == "E1":
            if ops % 20 < 17:
                store.read(1)
            else:
                store.write(generate_record())
        elif workload_key == "E2":
            if ops % 20 < 3:
                store.read(1)
            else:
                store.write(generate_record())
        elif workload_key == "E3":
            if ops % 2 == 0:
                store.read(1)
            else:
                store.write(generate_record())
        elif workload_key == "E4":
            store.scan(limit=100)
        elif workload_key == "E5":
            for _ in range(50):
                store.write(generate_record())
        else:
            store.write(generate_record())

        latencies.append((time.perf_counter() - t0) * 1000)
        ops += 1

    return ops, duration_s, mean(latencies) if latencies else 0.0

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--db", required=True, choices=["mongo", "cassandra", "couch"])
    parser.add_argument("--workload", required=True, choices=list(WORKLOADS.keys()))
    parser.add_argument("--repeats", type=int, default=1)
    parser.add_argument("--duration", type=int, default=30)
    args = parser.parse_args()

    out = MetricWriter()
    for rep in range(1, args.repeats + 1):
        ops, duration_s, avg_latency_ms = benchmark(args.db, args.workload, args.duration)
        out.write_row(
            db=args.db,
            workload=args.workload,
            fault="baseline",
            rep=rep,
            ops=ops,
            duration_s=duration_s,
            throughput_ops_sec=round(ops / duration_s, 3),
            avg_latency_ms=round(avg_latency_ms, 3),
            note="baseline run"
        )
        print(f"{args.db} {args.workload} rep={rep} ops={ops} throughput={ops/duration_s:.2f}")
    out.close()

if __name__ == "__main__":
    main()
