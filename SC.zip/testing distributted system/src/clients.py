from pymongo import MongoClient
from cassandra.cluster import Cluster
import requests

from config import (
    MONGO_URI, MONGO_DB, MONGO_COLLECTION,
    CASSANDRA_HOSTS, CASSANDRA_KEYSPACE,
    COUCH_BASE_URL, COUCH_DB
)

class MongoStore:
    def __init__(self):
        self.client = MongoClient(MONGO_URI)
        self.col = self.client[MONGO_DB][MONGO_COLLECTION]

    def write(self, record):
        return self.col.insert_one(record)

    def read(self, device_id):
        return self.col.find_one({"device_id": device_id}, sort=[("ts", -1)])

    def scan(self, limit=100):
        return list(self.col.find({}).sort("ts", -1).limit(limit))

class CassandraStore:
    def __init__(self):
        self.cluster = Cluster(CASSANDRA_HOSTS)
        self.session = self.cluster.connect(CASSANDRA_KEYSPACE)

    def write(self, record):
        q = (
            "INSERT INTO iot (device_id, ts, temperature, humidity, payload) "
            "VALUES (%s, toTimestamp(now()), %s, %s, %s)"
        )
        return self.session.execute(q, (record["device_id"], record["temperature"], record["humidity"], record["payload"]))

    def read(self, device_id):
        q = "SELECT * FROM iot WHERE device_id=%s LIMIT 1"
        return self.session.execute(q, (device_id,))

    def scan(self, limit=100):
        q = f"SELECT * FROM iot LIMIT {limit}"
        return self.session.execute(q)

class CouchStore:
    def __init__(self):
        self.base = COUCH_BASE_URL
        self.db = COUCH_DB
        requests.put(f"{self.base}/{self.db}")

    def write(self, record):
        doc = {"_id": f"{record['device_id']}-{record['ts']}", **record}
        return requests.post(f"{self.base}/{self.db}", json=doc, timeout=10)

    def read(self, device_id):
        return requests.get(
            f"{self.base}/{self.db}/_all_docs",
            params={"limit": 1, "include_docs": True},
            timeout=10,
        ).json()

    def scan(self, limit=100):
        return requests.get(
            f"{self.base}/{self.db}/_all_docs",
            params={"limit": limit, "include_docs": True},
            timeout=10,
        ).json()

def get_store(name):
    name = name.lower()
    if name == "mongo":
        return MongoStore()
    if name == "cassandra":
        return CassandraStore()
    if name == "couch":
        return CouchStore()
    raise ValueError(f"Unknown db: {name}")
