MONGO_URI = "mongodb://localhost:27017/?replicaSet=rs0"
MONGO_DB = "edge_stress"
MONGO_COLLECTION = "iot"

CASSANDRA_HOSTS = ["127.0.0.1"]
CASSANDRA_KEYSPACE = "edge_stress"

COUCH_BASE_URL = "http://admin:password@localhost:5984"
COUCH_DB = "edge_stress"
