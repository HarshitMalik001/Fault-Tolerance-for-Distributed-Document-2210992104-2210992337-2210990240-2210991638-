#!/usr/bin/env bash
set -euo pipefail

# F1: Single-node crash
fault_f1() {
  docker kill "$1"
}

# F2: Network partition to one node for 60 seconds
fault_f2() {
  local target_ip="$1"
  iptables -A OUTPUT -d "$target_ip" -j DROP
  sleep 60
  iptables -D OUTPUT -d "$target_ip" -j DROP
}

# F3: Cascading failure
fault_f3() {
  docker kill "$1"
  sleep 10
  docker kill "$2"
}

# F4: Slow network
fault_f4() {
  local iface="$1"
  tc qdisc add dev "$iface" root netem delay 500ms
  sleep 60
  tc qdisc del dev "$iface" root netem
}

# F5: Split-brain style partition
fault_f5() {
  local ip_a="$1"
  local ip_b="$2"
  iptables -A OUTPUT -d "$ip_a" -j DROP
  iptables -A OUTPUT -d "$ip_b" -j DROP
}
