import random
import time
import uuid

def generate_record():
    return {
        "device_id": random.randint(1, 100_000),
        "ts": int(time.time() * 1000),
        "temperature": round(random.uniform(18, 42), 2),
        "humidity": round(random.uniform(20, 90), 2),
        "payload": str(uuid.uuid4())[:16],
    }
